package com.example.dodgegame;

import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.Timer;
import java.util.ArrayList;
import java.util.Random;

public class GamePanel extends JPanel implements ActionListener {
    private final int WIDTH = 800;
    private final int HEIGHT = 600;
    private final int DELAY = 10;
    private Timer timer;
    private Player player;
    private ArrayList<Obstacle> obstacles;
    private Random random;
    private JButton startButton;
    private boolean inGame;

    public GamePanel() {
        setPreferredSize(new Dimension(WIDTH, HEIGHT));
        setBackground(Color.BLACK);
        setLayout(null);
        initGame();
    }

    private void initGame() {
        inGame = false;
        player = new Player(WIDTH / 2, HEIGHT - 50);
        obstacles = new ArrayList<>();
        random = new Random();
        timer = new Timer(DELAY, this);

        startButton = new JButton("Start");
        startButton.setBounds(WIDTH / 2 - 50, HEIGHT / 2 - 25, 100, 50);
        startButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                startGame();
            }
        });
        add(startButton);
    }

    public void startGame() {
        inGame = true;
        startButton.setVisible(false);
        addKeyListener(new TAdapter());
        setFocusable(true);
        timer.start();
    }

    private void gameOver() {
        inGame = false;
        timer.stop();
        JOptionPane.showMessageDialog(this, "Game Over", "Game Over", JOptionPane.YES_NO_OPTION);
        resetGame();
    }

    private void resetGame() {
        player = new Player(WIDTH / 2, HEIGHT - 50);
        obstacles.clear();
        startButton.setVisible(true);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (inGame) {
            draw(g);
        } else {
            drawMenu(g);
        }
    }

    private void draw(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
        player.draw(g2d);
        for (Obstacle obstacle : obstacles) {
            obstacle.draw(g2d);
        }
    }

    private void drawMenu(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
        g2d.setColor(Color.WHITE);
        g2d.drawString("Press Start to Begin", WIDTH / 2 - 60, HEIGHT / 2 - 50);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (inGame) {
            player.move();
            updateObstacles();
            checkCollisions();
            repaint();
        }
    }

    private void updateObstacles() {
        if (random.nextInt(100) < 5) {
            obstacles.add(new Obstacle(random.nextInt(WIDTH - 30), 0));
        }
        for (int i = 0; i < obstacles.size(); i++) {
            Obstacle obstacle = obstacles.get(i);
            obstacle.move();
            if (obstacle.getY() > HEIGHT) {
                obstacles.remove(i);
                i--;
            }
        }
    }

    private void checkCollisions() {
        for (Obstacle obstacle : obstacles) {
            if (player.getBounds().intersects(obstacle.getBounds())) {
                gameOver();
            }
        }
    }

    private class TAdapter extends KeyAdapter {
        @Override
        public void keyPressed(KeyEvent e) {
            player.keyPressed(e);
        }

        @Override
        public void keyReleased(KeyEvent e) {
            player.keyReleased(e);
        }
    }
}
