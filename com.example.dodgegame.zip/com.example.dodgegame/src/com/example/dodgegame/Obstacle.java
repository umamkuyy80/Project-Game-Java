package com.example.dodgegame;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;

public class Obstacle {
    private int x, y;
    private final int WIDTH = 30;
    private final int HEIGHT = 30;
    private final int DY = 2;

    public Obstacle(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public void move() {
        y += DY;
    }

    public void draw(Graphics2D g2d) {
        g2d.setColor(Color.RED);
        g2d.fillRect(x, y, WIDTH, HEIGHT);
    }

    public int getY() {
        return y;
    }

    public Rectangle getBounds() {
        return new Rectangle(x, y, WIDTH, HEIGHT);
    }
}
